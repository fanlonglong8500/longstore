package main

import (
	"encoding/binary"
	"fmt"
	"io/ioutil"
	"strconv"
)

type KeyGen struct {
	Seed0 [18]uint32
	Seed1 [256]uint32
	Seed2 [256]uint32
	Seed3 [256]uint32
	Seed4 [256]uint32
}

func StringToByte(src string) []byte {
	var err error
	var tmp int64

	l := len(src) / 2

	//fmt.Println("string len is ", l)

	ans := make([]byte, l, l)

	for i := 0; i < l; i++ {
		tmp, err = strconv.ParseInt(src[i*2:i*2+2], 16, 32)
		if err != nil {
			fmt.Println("StringToByte: ", err)
			return ans
		}

		ans[i] = byte(tmp)
	}

	return ans
}

func ArrayByteToUint32(dst []uint32, src []byte) {
	l := len(src)
	if len(dst)*4 < l {
		l = len(dst) * 4
	}

	for i := 0; i < l; i = i + 4 {
		dst[i/4] = binary.LittleEndian.Uint32(src[i : i+4])
	}
}

func (gen *KeyGen) KeySteps(w, w1 uint32) (uint32, uint32) {
	index := 17

	for j := 0; j < 16; j++ {
		var tmp uint32 = 0

		r := gen.Seed0[index] ^ w

		fmt.Printf("loop j %d w %x w1 %x r %x seed0 %x seed1 %x seed2 %x seed3 %x seed4 %x\n",
			j, w, w1, r, gen.Seed0[index], gen.Seed1[(r>>24)&0xff], gen.Seed2[(r>>16)&0xff],
			gen.Seed3[(r>>8)&0xff], gen.Seed4[r&0xff])

		index--

		tmp = gen.Seed1[(r>>24)&0xff] + gen.Seed2[(r>>16)&0xff]
		tmp = gen.Seed3[(r>>8)&0xff] ^ tmp
		tmp = tmp + gen.Seed4[r&0xff]

		w = w1 ^ tmp

		w1 = r
	}

	return w, w1
}

func (gen *KeyGen) GetKeys(src []byte, step int) ([]byte, error) {
	var rstep int = step

	ans := make([]byte, len(src), cap(src))

	for i := 0; i < rstep; i++ {
		//fmt.Printf("%d %d %d\n", i, len(src), rstep)

		w := binary.LittleEndian.Uint32(src[(i*2)*4 : (i*2+1)*4])
		w1 := binary.LittleEndian.Uint32(src[(i*2+1)*4 : (i*2+2)*4])

		fmt.Printf("s--i:%d [0:4]%x [4:8]%x\n", i, w, w1)

		w, w1 = gen.KeySteps(w, w1)

		fmt.Printf("e--i:%d [0:4]%x [4:8]%x\n", i, w, w1)

		binary.LittleEndian.PutUint32(ans[(i*2)*4:(i*2+1)*4], w1^gen.Seed0[0])
		binary.LittleEndian.PutUint32(ans[(i*2+1)*4:(i*2+2)*4], w^gen.Seed0[1])
	}

	fmt.Println(string(ans))

	return ans, nil
}

func (gen *KeyGen) LoadSeeds(filePath string) error {
	context, err := ioutil.ReadFile(filePath)
	if err != nil {
		return err
	}

	if len(context) < 4168 {
		return fmt.Errorf("file len less")
	}

	//fmt.Println("read len ", len(context))

	start := 0

	ArrayByteToUint32(gen.Seed0[:], context[start:18*4])

	fmt.Println(gen.Seed0[0])

	start = start + 18*4

	ArrayByteToUint32(gen.Seed1[:], context[start:start+1024])

	fmt.Println(gen.Seed1[0])

	start = start + 1024

	ArrayByteToUint32(gen.Seed2[:], context[start:start+1024])

	fmt.Println(gen.Seed2[0])

	start = start + 1024

	ArrayByteToUint32(gen.Seed3[:], context[start:start+1024])

	fmt.Println(gen.Seed3[0])

	start = start + 1024

	ArrayByteToUint32(gen.Seed4[:], context[start:start+1024])

	fmt.Println(gen.Seed4[0])

	return nil
}

func test1() {
	var input []byte

	gen := &KeyGen{}

	gen.LoadSeeds("F:\\source\\storeage\\stone-age-master\\stone-age-master\\client\\526sa\\key.mem")
	input = StringToByte("6F0224FAB045427A3797E297DA1C0877")
	gen.GetKeys(input, 2)

	/*
		for i := uint64(0); i <= uint64(0xFFFFFFFFFFFFFFFF); i++ {

			binary.LittleEndian.PutUint64(input[:], i)
			key, _ := gen.GetKeys(input[:], 1)
			if "cUeaQO0i" == string(key[0:8]) {
				println(input[:])
				break
			}

			if i%10000000 == 0 {
				println("cur i is ", i)
			}
		}
	*/
}
