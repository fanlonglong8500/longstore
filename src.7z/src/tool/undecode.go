package main

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"strconv"
	"strings"
	//	"bufio"
	//	"net"
	//	"socks5"
)

const (
	CTOS = 1
	STOC = 2
)

var constString []string = []string{"CTOS", "STOC"}

type DataParse struct {
	Key string
}

var defaultTable string = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz{}"

func xorAllData(srcData []byte) {
	for i, value := range srcData {
		srcData[i] = value ^ 0xff
	}
}

func exchangeDataByOrder(srcData []byte, indexOfs [4]byte) {
	var ofsArr [4]byte = [4]byte{}

	for i, value := range indexOfs {
		ofsArr[i] = srcData[value-1]
	}

	copy(srcData, ofsArr[0:4])
}

func getDataOfs(srcData []byte, indexOfs [4]byte) uint32 {
	var ofsArr [4]byte = [4]byte{}

	for i, value := range indexOfs {
		ofsArr[i] = srcData[value-1]
	}

	return binary.LittleEndian.Uint32(ofsArr[:])
}

func bit6Tobit8WithKeyShr(srcData, key []byte) []byte {
	var dw int = 0
	var allBit int = 0

	dst := make([]byte, 0, cap(srcData))
	iKey := 0

	//fmt.Println(string(srcData))

	for _, value := range srcData {

		//fmt.Printf("%x %x %x\n", int32(strings.IndexByte(defaultTable, value)), int32(key[iKey]), dw)

		dd := (int32(strings.IndexByte(defaultTable, value)) + int32(key[iKey])) & 0x3f
		dw = dw | (int(dd) << uint32(allBit))

		allBit += 6

		iKey += 1
		if iKey == len(key) {
			iKey = 0
		}

		if allBit >= 8 {
			dst = append(dst, byte(dw&0xff))
			allBit -= 8
			dw >>= 8
		}
	}

	return dst
}

func bit6Tobit8WithKeyShl(srcData, key []byte) []byte {
	var dw int = 0
	var allBit int = 0

	dst := make([]byte, 0, cap(srcData))
	iKey := 0

	for _, value := range srcData {
		dd := (int32(strings.IndexByte(defaultTable, value)) - int32(key[iKey])) & 0x3f
		dw = dw | (int(dd) << uint32(allBit))

		allBit += 6

		iKey += 1
		if iKey == len(key) {
			iKey = 0
		}

		if allBit >= 8 {
			dst = append(dst, byte(dw&0xff))
			allBit -= 8
			dw >>= 8
		}
	}

	return dst
}

func bit8Tobit6WithKeyShr(srcData, key []byte) []byte {
	var dw int = 0
	var allBit int = 0

	dst := make([]byte, 0, cap(srcData)*2)
	iKey := 0

	for _, value := range srcData {
		dw = dw | int(value)<<uint32(allBit)
		allBit = allBit + 8

		for ; allBit >= 6; allBit = allBit - 6 {
			dd := ((dw & 0x3f) + int(key[iKey])) & 0x3f
			dst = append(dst, defaultTable[dd])

			iKey = iKey + 1
			if iKey == len(key) {
				iKey = 0
			}

			dw = dw >> 6
		}
	}

	if allBit > 0 {

		dd := ((dw & 0x3f) + int(key[iKey])) & 0x3f

		//fmt.Printf("dw %d ikey %d key %d dd %d\n", dw, iKey, key[iKey], dd)

		dst = append(dst, defaultTable[dd])
	}

	return dst
}

func bit8Tobit6WithKeyShl(srcData, key []byte) []byte {
	var dw int = 0
	var allBit int = 0

	dst := make([]byte, 0, cap(srcData)*2)
	iKey := 0

	for _, value := range srcData {
		dw = dw | int(value)<<uint32(allBit)
		allBit = allBit + 8

		for ; allBit >= 6; allBit = allBit - 6 {
			dd := ((dw & 0x3f) - int(key[iKey])) & 0x3f
			dst = append(dst, defaultTable[dd])

			iKey = iKey + 1
			if iKey == len(key) {
				iKey = 0
			}

			dw = dw >> 6
		}
	}

	if allBit > 0 {
		dd := ((dw & 0x3f) - int(key[iKey])) & 0x3f

		//fmt.Printf("dw %d ikey %d key %d dd %d\n", dw, iKey, key[iKey], dd)

		dst = append(dst, defaultTable[dd])
	}

	return dst
}

func bit6Tobit8(srcData []byte) []byte {
	var dw int = 0
	var allBit int = 0

	dst := make([]byte, 0, cap(srcData))

	for _, value := range srcData {
		//fmt.Printf("%d %c %d\n", dw, value, strings.IndexByte(defaultTable, value) )
		dw = dw | ((strings.IndexByte(defaultTable, value) & 0x3f) << uint32(allBit))
		allBit += 6

		if allBit >= 8 {
			dst = append(dst, byte(dw&0xff))
			allBit -= 8
			dw >>= 8
		}
	}

	//fmt.Println(dst)

	return dst
}

func bit8Tobit6(srcData []byte) []byte {
	var dw int = 0
	var allBit int = 0

	dst := make([]byte, 0, cap(srcData)*2)

	for _, value := range srcData {
		dw = dw | int(value)<<uint32(allBit)
		allBit = allBit + 8

		for ; allBit >= 6; allBit = allBit - 6 {
			dst = append(dst, defaultTable[dw&0x3f])

			dw = dw >> 6
		}
	}

	if allBit > 0 {
		dst = append(dst, defaultTable[dw&0x3f])
	}

	return dst
}

func exchageData(srcData []byte, ofs uint32) {
	tmpData := make([]byte, len(srcData), cap(srcData))

	ofs = uint32(len(srcData) - int(ofs)%len(srcData))

	copy(tmpData[0:], srcData[ofs:])
	copy(tmpData[uint32(len(srcData))-ofs:], srcData[0:ofs])

	//fmt.Println(tmpData)
	//fmt.Println(srcData)
	//fmt.Println(ofs," ",len(srcData))

	copy(srcData, tmpData)
}

func (parser *DataParse) GetCommandID(src []byte) (int, int, [][]byte, error) {
	var messageDirection int

	ans, err := parser.SpilceCommand(src)
	if nil != err {
		return 0, 0, [][]byte{}, fmt.Errorf("Spilce err")
	}

	switch string(ans[0]) {
	case "(&":
		messageDirection = CTOS
	case "&":
		messageDirection = STOC
	default:
		return 0, 0, [][]byte{}, fmt.Errorf("header flags err")
	}

	if string(ans[len(ans)-2]) != "#" {
		return 0, 0, [][]byte{}, fmt.Errorf("tailer flags err")
	}

	cmdId, err := strconv.Atoi(string(ans[1]))
	if nil != err {
		return 0, 0, [][]byte{}, err
	}

	return cmdId, messageDirection, ans[2 : len(ans)-2], nil
}

func (parser *DataParse) SpilceCommand(src []byte) ([][]byte, error) {
	return bytes.Split(src[6:], []byte(";")), nil
}

func (parser *DataParse) DeString(src []byte) ([]byte, error) {
	return bit6Tobit8WithKeyShr(src, []byte(parser.Key)), nil
}

func (parser *DataParse) DeInt(src []byte) (uint32, error) {
	if len(src) < 6 {
		return 0, fmt.Errorf("less byte")
	}

	ans := bit6Tobit8WithKeyShl(src, []byte(parser.Key))
	xorAllData(ans[0:len(ans)])

	return getDataOfs(ans, [4]byte{3, 1, 4, 2}), nil
}

func (parser *DataParse) MkString(src []byte) ([]byte, error) {

	return bit8Tobit6WithKeyShl(src, []byte(parser.Key)), nil
}

func (parser *DataParse) MkInt(src uint32) ([]byte, error) {
	var srcByte [8]byte

	binary.LittleEndian.PutUint32(srcByte[0:4], src)

	exchangeDataByOrder(srcByte[0:4], [4]byte{2, 4, 1, 3})
	xorAllData(srcByte[0:4])

	return bit8Tobit6WithKeyShr(srcByte[0:4], []byte(parser.Key)), nil
}

func (parser *DataParse) AppendMkString(dst []byte, src []byte) ([]byte, int, error) {
	tmp, err := parser.MkString(src)
	if err != nil {
		return dst, 0, err
	}

	dst = append(dst, ';')
	dst = append(dst, tmp...)

	return dst, len(src), nil
}

func (parser *DataParse) AppendMkInt(dst []byte, src int) ([]byte, int, error) {
	tmp, err := parser.MkInt(uint32(src))
	if err != nil {
		return dst, 0, err
	}

	dst = append(dst, ';')
	dst = append(dst, tmp...)

	return dst, src, nil
}

func (parser *DataParse) DecodeData(srcData []byte) ([]byte, error) {
	dst := make([]byte, len(srcData), cap(srcData)*3)

	//1 copy
	copy(dst, srcData)

	if dst[len(dst)-1] == 0x0a {
		dst[len(dst)-1] = 0
	} else {
		return srcData, nil
	}

	//2 xor
	xorAllData(dst[0 : len(dst)-1])

	//3 randNum
	rofs := bit6Tobit8(dst[0:6])
	xorAllData(rofs[0:4])
	randNum := getDataOfs(rofs, [4]byte{2, 4, 1, 3})

	//4 exchange
	exchageData(dst[6:len(dst)-1], randNum)

	return dst, nil
}

func (parser *DataParse) EncodeData(srcData []byte) ([]byte, error) {
	dst := make([]byte, 0, cap(srcData)*3)

	//使用了zero,所以不用调换字符串
	zero := [4]byte{0, 0, 0, 0}
	xorAllData(zero[0:4])

	dst = append(dst, bit8Tobit6(zero[0:4])...)
	dst = append(dst, srcData...)

	xorAllData(dst)

	dst = append(dst, 0x0a)

	return dst, nil
}

func (parser *DataParse) GenCommand(cmdId int, dir int, srcData []byte) ([]byte, error) {
	if dir == STOC {
		return []byte(fmt.Sprintf("&;%d%s;#;", cmdId, string(srcData))), nil
	} else {
		return []byte(fmt.Sprintf("(&;%d%s;#;", cmdId, string(srcData))), nil
	}
}

/////////////////////////tttttestiiiii///////////////////////////////////////////
////////////////////////////tttttestiiiii///////////////////////////////////////////
////////////////////////////tttttestiiiii///////////////////////////////////////////
////////////////////////////tttttestiiiii///////////////////////////////////////////
/////////////////////////tttttestiiiii///////////////////////////////////////////

var t DataParse

func printlog1(cmdLst [][]byte, key []byte) {
	for _, value := range cmdLst[0:len(cmdLst)] {
		fmt.Println(string(value))

		ans := bit6Tobit8WithKeyShl(value, key)
		ans1 := bit8Tobit6WithKeyShr(ans, key)
		ans2 := bit6Tobit8WithKeyShl(ans1, key)
		fmt.Println(string(ans))
		fmt.Println((ans))
		fmt.Println(ans2)
		fmt.Println(ans1)
		fmt.Println(value)

		ans = bit6Tobit8WithKeyShr(value, key)
		ans1 = bit8Tobit6WithKeyShl(ans, key)
		ans2 = bit6Tobit8WithKeyShr(ans1, key)
		fmt.Println(string(ans))
		fmt.Println((ans))
		fmt.Println(ans2)
		fmt.Println(ans1)
		fmt.Println(value)
	}

	for i := 0; i < 256; i++ {
		value := [1]byte{255}
		value[0] = byte(i)

		for j := 0; j < 256; j++ {

			key1 := [1]byte{255}
			key1[0] = byte(j)

			ans1 := bit8Tobit6WithKeyShr(value[0:1], key1[0:1])
			ans := bit6Tobit8WithKeyShl(ans1, key1[0:1])

			if ans[0] != value[0] {
				fmt.Println("not ==========")
			}

			ans1 = bit8Tobit6WithKeyShl(value[0:1], key1[0:1])
			ans = bit6Tobit8WithKeyShr(ans1, key1[0:1])

			if ans[0] != value[0] {
				fmt.Println("not ==========")
			}
		}

	}
}

func printlog(cmdLst [][]byte, key []byte) {
	t.Key = string(key)
	fmt.Println(string(cmdLst[1]))

	for _, value := range cmdLst[2 : len(cmdLst)-1] {
		fmt.Println(string(value))

		ans, _ := t.DeString(value)
		fmt.Println(string(ans))

		ans1, _ := t.DeInt(value)
		fmt.Println((ans1))
	}
}

func test() {
	var err error
	var hler CmdHandler

	src0 := []byte{
		0x82, 0x82, 0x89, 0x82, 0x82, 0xcc, 0xb8, 0xb6,
		0xc4, 0xdc, 0xc4, 0xd7, 0xd9, 0xc4, 0xc7, 0xcb,
		0xc4, 0xb7, 0xcc, 0x94, 0x95, 0xa5, 0xce, 0xa5,
		0x9d, 0xb4, 0x82, 0xaa, 0xc4, 0xba, 0x8f, 0xba,
		0x97, 0xa5, 0xca, 0x8f, 0x9e, 0xb4, 0xbd, 0x94,
		0x95, 0xc4, 0xbb, 0x97, 0x94, 0x98, 0x9e, 0x91,
		0xa5, 0xa6, 0xb6, 0xcc, 0x94, 0x98, 0x90, 0x90,
		0xa5, 0xa6, 0xbb, 0x97, 0x94, 0x98, 0xa9, 0x8d,
		0xb5, 0x9a, 0xa6, 0x8a, 0xb8, 0x91, 0xcc, 0x94,
		0xb4, 0x97, 0xbe, 0xad, 0x93, 0x8e, 0x8a, 0xba,
		0xa5, 0x9a, 0xb8, 0x8f, 0xaa, 0xc4, 0xab, 0x8a,
		0x95, 0x9a, 0xb3, 0x8d, 0xa6, 0xa7, 0xc4, 0xc4,
		0xa6, 0xb4, 0xcb, 0xab, 0xb8, 0xb6, 0xc4, 0xa6,
		0xb4, 0xb4, 0xb9, 0x0a}

	src1 := []byte{
		0x82, 0xa9, 0x85, 0x82, 0x82, 0xcc, 0xc4, 0x87,
		0x8b, 0xbb, 0xc4, 0x8f, 0x8d, 0xb0, 0x8f, 0x8f,
		0x86, 0xc4, 0xdc, 0xc4, 0xd9, 0xc4, 0xc6, 0xca,
		0x0a}

	src2 := []byte{
		0x82, 0xcc, 0x85, 0x82, 0x82, 0xcc, 0xc4, 0xc6,
		0xcd, 0xc4, 0x8f, 0x8d, 0x8a, 0x8f, 0x8f, 0x86,
		0xc4, 0xdc, 0xc4, 0xd7, 0xd9, 0x0a}

	src3 := []byte{
		0x82, 0x97, 0x87, 0x82, 0x82, 0xcc, 0xcf, 0xbe,
		0xbe, 0xa5, 0xc9, 0xbc, 0xbc, 0xb1, 0xbb, 0xad,
		0xcf, 0x85, 0xa8, 0x91, 0xa5, 0xa5, 0xcc, 0xb6,
		0x98, 0xb0, 0x9a, 0x92, 0xa8, 0xb1, 0xbb, 0x97,
		0xaa, 0x8c, 0x99, 0x90, 0xb5, 0x94, 0xc9, 0x82,
		0xaf, 0xb0, 0x86, 0xc8, 0xbc, 0xa6, 0xb1, 0x96,
		0xaa, 0x8c, 0x99, 0xc9, 0xb5, 0x9d, 0x9a, 0x8f,
		0xba, 0x9b, 0x95, 0xbc, 0x82, 0xa5, 0x89, 0xb4,
		0xb6, 0xba, 0x91, 0x8e, 0x87, 0xc8, 0xb3, 0xce,
		0xa6, 0x89, 0xb8, 0xbe, 0x9c, 0x8f, 0xb5, 0x85,
		0xb2, 0xba, 0xba, 0xcf, 0xae, 0xcb, 0xba, 0xa7,
		0xb7, 0xa5, 0xca, 0x92, 0xb8, 0xb1, 0xc4, 0x8f,
		0x8d, 0x8a, 0xb1, 0x8f, 0x86, 0xc4, 0xdc, 0xc4,
		0xd9, 0xc4, 0xce, 0xcf, 0xcc, 0xc4, 0x82, 0xa9,
		0x84, 0x9e, 0x93, 0xac, 0x82, 0x9b, 0xb8, 0xcb,
		0x91, 0x86, 0xad, 0x90, 0xc4, 0x8a, 0xb9, 0xab,
		0x9e, 0x93, 0x8a, 0xb8, 0xb1, 0x89, 0xb4, 0xb6,
		0x97, 0xa9, 0xca, 0xb5, 0xa5, 0x86, 0x88, 0x96,
		0x98, 0x85, 0xb5, 0xac, 0xb0, 0x89, 0xb4, 0x90,
		0x97, 0xa9, 0xc6, 0xa5, 0xa5, 0x9a, 0x8f, 0xaa,
		0xb0, 0x84, 0xa9, 0xbc, 0xa6, 0xb1, 0xcb, 0x84,
		0x96, 0xbd, 0xae, 0x9b, 0xa5, 0x0a}

	src4 := []byte{
		0x82, 0x9b, 0x86, 0x82, 0x82, 0xcc, 0x93, 0xc7,
		0xc4, 0x8f, 0x8d, 0x8a, 0x90, 0x8f, 0x86, 0xc4,
		0xdc, 0xc4, 0xd7, 0xd9, 0xc4, 0xc6, 0xcf, 0xc4,
		0x8a, 0xb9, 0xab, 0x9e, 0x0a}

	fmt.Println("1c->s:")
	srcData, _ := t.DecodeData(src0)
	cmdLst, _ := t.SpilceCommand(srcData)
	printlog(cmdLst, []byte("cUeaQO0icUeaQO0i"))

	fmt.Println("2s->c:")
	srcData, _ = t.DecodeData(src1)
	cmdLst, _ = t.SpilceCommand(srcData)
	printlog(cmdLst, []byte("46944975cUeaQO0i"))

	fmt.Println("3c->s:")
	srcData, _ = t.DecodeData(src2)
	cmdLst, _ = t.SpilceCommand(srcData)
	printlog(cmdLst, []byte("46944975cUeaQO0i"))

	fmt.Println("4s->c:")
	srcData, _ = t.DecodeData(src3)
	cmdLst, _ = t.SpilceCommand(srcData)
	printlog(cmdLst, []byte("46944975cUeaQO0i"))

	fmt.Println("5c->s:")
	srcData, _ = t.DecodeData(src4)
	cmdLst, _ = t.SpilceCommand(srcData)
	printlog(cmdLst, []byte("46944975cUeaQO0i"))

	id, msgDir, cmdLst, err := t.GetCommandID(srcData)
	if nil != err {
		fmt.Println(err.Error())
		return
	}

	fmt.Printf("ID is %d, msgDir %d :\n", id, msgDir)
	printlog1(cmdLst, []byte("46944975cUeaQO0i"))

	hler.HandleCmd(id, msgDir, cmdLst, &t)
	/*
		conf := &socks5.Config{}
		server, err := socks5.New(conf, nil)
		if err != nil {
			fmt.Println("socks5 new error")
			return
		}

		listenAddr := "127.0.0.1:8000"

		fmt.Println("listener ", listenAddr)

		// Create SOCKS5 proxy on localhost port 8000
		if err := server.ListenAndServe("tcp", listenAddr); err != nil {
			fmt.Println("socks5 new error")
			return
		}
	*/
}
