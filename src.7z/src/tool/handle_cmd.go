package main

import (
	"fmt"
)

type CmdHandler struct {
	Name string
}

func (handler *CmdHandler) HandleCmd(cmd int, dir int, context [][]byte, parser *DataParse) (int, error) {

	cmdRealId := 0
	if dir == CTOS {
		cmdRealId = cmd - 13
	} else {
		cmdRealId = cmd - 23
	}

	fmt.Println("finish ", cmdRealId)

	return 0, nil
}
