package main

import (
	"bytes"
	"fmt"
	"io"
	"strconv"
)

const (
	BATTLE_RECV_211 = 1
	BATTLE_RECV_7   = 2
	BATTLE_IN       = 3
	BATTLE_OUT      = 4
)

type cPet struct {
	name    [256]byte //要抓宠物的名字,二进制
	nameLen int
	level   int64 //要抓宠物的等级,不超过这个等级
	hp      int64 // 0 代表不关心血量，其他的值代表必须超过这个值
}

type battlerChar struct {
	battlerID int64
	name      [256]byte
	nameLen   int
	charId    int64
	level     int64
	hp        int64
	maxHp     int64
}

type OfflineBattler struct {
	battlerAction   int    // 1.逃跑 2.战斗
	capturePet      int    // 1.抓宠 0.不抓
	petLst          []cPet // 要抓宠物的列表
	cureLevel       int    //0-100 低于这个比例就治疗
	capturePetSkill int    //抓宠技能，一般是毒精灵
	cureSkill       int    //治疗精灵，血低于curelevel是使用这个技能治疗
	status          int

	charLst         [200]battlerChar //当前战斗的状态值，每次BC的时候更新
	charLen         int
	battlerAtt      int64 // 0 无  1 地 2 水 3 火 4 风
	battlerOpr      bool
	battlerWaitCmd2 bool
}

func GetRealCmd(cmd, dir int) int {
	cmdRealId := 0
	if dir == CTOS {
		cmdRealId = cmd - 13
	} else {
		cmdRealId = cmd - 23
	}

	return cmdRealId
}

func (battler *OfflineBattler) ChangeStatus(cmd int) {
	switch cmd {
	case 211:
		battler.status = BATTLE_RECV_211
	case 7:
		battler.status = BATTLE_RECV_7
	case 15:
		battler.status = BATTLE_IN
	}
}

var outFmtCmd map[int]int = map[int]int{
	211: 1,
	//46:  1,
	14: 1,
	15: 1,
	7:  1,
	2:  1,
}

const (
	CHARBATTLEID = iota
	CHARNAME
	CHARTITLE
	CHARID
	CHARLEVEL
	CHARHP
	CHARMAXHP
	CHARFLAG
	CHARRIDEFLAG
	CHARRIDENAME
	CHARRIDELEVEL
	CHARRIDEHP
	CHARRIDEMAXHP
)

const (
	PET = iota
	PERSON
)

func (battler *OfflineBattler) FindLessHP() (int, error) {
	for i := 0; i < battler.charLen; i++ {
		if battler.charLst[i].battlerID >= 10 {
			continue
		}

		if battler.charLst[i].hp*100 <= battler.charLst[i].maxHp*int64(battler.cureLevel) {
			return i, nil
		}
	}

	return -1, fmt.Errorf("NOT FOUND")
}

func (battler *OfflineBattler) FindAttackChar() (int, error) {
	for i := 0; i < battler.charLen; i++ {
		bchar := battler.charLst[i]

		if bchar.battlerID < 10 {
			continue
		}

		if bchar.hp > 0 {
			return i, nil
		}
	}

	return -1, fmt.Errorf("NOT FOUND")
}

func (battler *OfflineBattler) FindCapturePet() (int, error) {
	for i := 0; i < battler.charLen; i++ {
		bchar := battler.charLst[i]

		if bchar.battlerID < 10 {
			continue
		}

		for j := 0; j < len(battler.petLst); j++ {
			bname := bchar.name[0:bchar.nameLen]
			pname := battler.petLst[j].name[0:battler.petLst[j].nameLen]

			//fmt.Println(bname, " ", pname, " ", bchar.level, " ", battler.petLst[j].level)

			if 0 == bytes.Compare(bname, pname) &&
				bchar.level <= battler.petLst[j].level &&
				bchar.maxHp >= battler.petLst[j].hp {
				return i, nil
			}
		}
	}

	return -1, fmt.Errorf("NOT FOUND")
}

func (battler *OfflineBattler) replyFinishBattle(
	parser *DataParse, pass io.Writer, reply io.Writer) {

	sendBuf := make([]byte, 0, 4*1024)
	sum := 0

	sendBuf, t, _ := parser.AppendMkInt(sendBuf, 12)
	sum = sum + t
	sendBuf, t, _ = parser.AppendMkInt(sendBuf, sum)

	sendBuf, _ = parser.GenCommand(21, CTOS, sendBuf)
	sendBuf, _ = parser.EncodeData(sendBuf)

	fmt.Println(sendBuf)

	reply.Write(sendBuf)
}

func (battler *OfflineBattler) PlayerAction(player int,
	parser *DataParse, pass io.Writer, reply io.Writer) error {
	var out string
	i, err := battler.FindAttackChar()
	if err != nil { //没找到攻击对象,直接退出
		return nil
	}

	i, err = battler.FindLessHP()
	if err != nil { //没找到就不用治疗
		if battler.capturePet > 0 { //抓宠模式
			i, err = battler.FindCapturePet()
			if nil == err { //找到
				if PERSON == player {
					if battler.charLst[i].hp > 30 {
						out = fmt.Sprintf("J|%x|%x", battler.capturePetSkill, battler.charLst[i].battlerID)
					} else {
						out = fmt.Sprintf("T|%x", battler.charLst[i].battlerID)
					}

				} else {
					out = fmt.Sprintf("W|1|0")
				}
				goto SENDMSG
			}
		}

		if battler.battlerAction == 1 { // 逃跑模式
			if PERSON == player {
				out = fmt.Sprintf("E")
			} else {
				out = fmt.Sprintf("W|FF|FF")
			}
		} else { //杀敌模式
			i, err = battler.FindAttackChar()
			if nil == err { //找到
				if PERSON == player {
					out = fmt.Sprintf("H|%x", battler.charLst[i].battlerID)
				} else {
					out = fmt.Sprintf("W|0|%x", battler.charLst[i].battlerID)
				}
			} else { //没找到攻击对象
				return nil
			}
		}
	} else { //治疗的逻辑
		if PERSON == player {
			out = fmt.Sprintf("J|%x|%x", battler.cureSkill, battler.charLst[i].battlerID)
		} else {
			if battler.capturePet > 0 { //抓宠模式就防御
				out = fmt.Sprintf("W|1|0")
			} else {
				i, err = battler.FindAttackChar()
				if nil == err { //找到
					out = fmt.Sprintf("W|0|%x", battler.charLst[i].battlerID)
				} else { //没找到攻击对象
					return nil
				}
			}
		}
	}
SENDMSG:

	fmt.Printf("%d %s\n", player, out)

	sendBuf := make([]byte, 0, 4*1024)
	sum := 0

	sendBuf, t, _ := parser.AppendMkString(sendBuf, []byte(out))
	sum = sum + t

	sendBuf, _, _ = parser.AppendMkInt(sendBuf, sum)

	sendBuf, _ = parser.GenCommand(27, CTOS, sendBuf)
	sendBuf, _ = parser.EncodeData(sendBuf)

	reply.Write(sendBuf)

	return nil
}

func (battler *OfflineBattler) ShowCharStatus() {
	fmt.Printf("%10s %10s %10s %10s %10s %s\n", "battlerID", "charID", "LEVEL", "HP", "MAXHP", "name")

	for j := 0; j < battler.charLen; j++ {
		fmt.Printf("%10x %10x %10d %10d %10d %v\n",
			battler.charLst[j].battlerID, battler.charLst[j].charId, battler.charLst[j].level,
			battler.charLst[j].hp, battler.charLst[j].maxHp,
			battler.charLst[j].name[0:battler.charLst[j].nameLen])
	}
}

func (battler *OfflineBattler) HandleCmd15BA(cmd int, dir int, cmdLst [][]byte,
	parser *DataParse, pass io.Writer, reply io.Writer) (int, []byte, error) {

	endBit, err := strconv.ParseInt(string(cmdLst[1]), 16, 32)
	if err != nil {
		fmt.Println("parser BC 1 ERR ", cmdLst[1])
		return BYPASS, cmdLst[1], fmt.Errorf("parser BA 1 ERR")
	}

	turn, err := strconv.ParseInt(string(cmdLst[2]), 16, 32)
	if err != nil {
		fmt.Println("parser BA 2 ERR ", cmdLst[2])
		return BYPASS, cmdLst[2], fmt.Errorf("parser BA 2 ERR")
	}

	fmt.Printf("%x %d\n", endBit, turn)

	if endBit&0x3ff == 0 {
		battler.battlerOpr = false
	}

	if false == battler.battlerOpr {
		battler.battlerOpr = true

		_, err := battler.FindAttackChar()
		if err != nil {
			battler.battlerWaitCmd2 = true
		} else {

			//1.person
			battler.PlayerAction(PERSON, parser, pass, reply)

			//2.PET
			battler.PlayerAction(PET, parser, pass, reply)
		}

	}

	return FILTER, cmdLst[0], nil
}

func (battler *OfflineBattler) HandleCmd15BC(cmd int, dir int, cmdLst [][]byte,
	parser *DataParse, pass io.Writer, reply io.Writer) (int, []byte, error) {

	var err error

	battler.battlerAtt, err = strconv.ParseInt(string(cmdLst[1]), 16, 32)
	if err != nil {
		fmt.Println("parser BC 1 ERR ", cmdLst[1])
		return BYPASS, cmdLst[1], fmt.Errorf("parser BC 1 ERR")
	}

	charLst := cmdLst[2:]
	j := 0

	l := len(charLst) - (len(charLst) % 13)

	for i := 0; i < l; i = i + 13 {
		battler.charLst[j].battlerID, err = strconv.ParseInt(string(charLst[i+CHARBATTLEID]), 16, 32)
		if err != nil {
			fmt.Println("parser BC ", i+CHARBATTLEID+2, " ERR ", charLst[i+CHARBATTLEID])
			return BYPASS, cmdLst[1], fmt.Errorf("parser BC %d ERR", i+CHARBATTLEID+2)
		}

		copy(battler.charLst[j].name[0:], charLst[i+CHARNAME])
		battler.charLst[j].nameLen = len(charLst[i+CHARNAME])

		battler.charLst[j].charId, err = strconv.ParseInt(string(charLst[i+CHARID]), 16, 32)
		if err != nil {
			fmt.Println("parser BC ", i+CHARID+2, " ERR ", charLst[i+CHARID])
			return BYPASS, cmdLst[1], fmt.Errorf("parser BC %d ERR", i+CHARID+2)
		}

		battler.charLst[j].level, err = strconv.ParseInt(string(charLst[i+CHARLEVEL]), 16, 32)
		if err != nil {
			fmt.Println("parser BC ", i+CHARLEVEL+2, " ERR ", charLst[i+CHARLEVEL])
			return BYPASS, cmdLst[1], fmt.Errorf("parser BC %d ERR", i+CHARLEVEL+2)
		}

		battler.charLst[j].hp, err = strconv.ParseInt(string(charLst[i+CHARHP]), 16, 32)
		if err != nil {
			fmt.Println("parser BC ", i+CHARHP+2, " ERR ", charLst[i+CHARHP])
			return BYPASS, cmdLst[1], fmt.Errorf("parser BC %d ERR", i+CHARHP+2)
		}

		battler.charLst[j].maxHp, err = strconv.ParseInt(string(charLst[i+CHARMAXHP]), 16, 32)
		if err != nil {
			fmt.Println("parser BC ", i+CHARMAXHP+2, " ERR ", charLst[i+CHARMAXHP])
			return BYPASS, cmdLst[1], fmt.Errorf("parser BC %d ERR", i+CHARMAXHP+2)
		}

		j = j + 1

		s, err := strconv.ParseInt(string(charLst[i+CHARRIDEFLAG]), 16, 32)
		if err != nil {
			fmt.Println("parser BC ", i+CHARRIDEFLAG+2, " ERR ", charLst[i+CHARRIDEFLAG])
			return BYPASS, cmdLst[1], fmt.Errorf("parser BC %d ERR", i+CHARRIDEFLAG+2)
		}

		if s > 0 {
			battler.charLst[j].battlerID = battler.charLst[j-1].battlerID

			copy(battler.charLst[j].name[0:], charLst[i+CHARRIDENAME])
			battler.charLst[j].nameLen = len(charLst[i+CHARRIDENAME])

			battler.charLst[j].charId = -1

			battler.charLst[j].level, err = strconv.ParseInt(string(charLst[i+CHARRIDELEVEL]), 16, 32)
			if err != nil {
				fmt.Println("parser BC ", i+CHARRIDELEVEL+2, " ERR ", charLst[i+CHARRIDELEVEL])
				return BYPASS, cmdLst[1], fmt.Errorf("parser BC %d ERR", i+CHARRIDELEVEL+2)
			}

			battler.charLst[j].hp, err = strconv.ParseInt(string(charLst[i+CHARRIDEHP]), 16, 32)
			if err != nil {
				fmt.Println("parser BC ", i+CHARRIDEHP+2, " ERR ", charLst[i+CHARRIDEHP])
				return BYPASS, cmdLst[1], fmt.Errorf("parser BC %d ERR", i+CHARRIDEHP+2)
			}

			battler.charLst[j].maxHp, err = strconv.ParseInt(string(charLst[i+CHARRIDEMAXHP]), 16, 32)
			if err != nil {
				fmt.Println("parser BC ", i+CHARRIDEMAXHP+2, " ERR ", charLst[i+CHARRIDEMAXHP])
				return BYPASS, cmdLst[1], fmt.Errorf("parser BC %d ERR", i+CHARRIDEMAXHP+2)
			}

			j = j + 1
		}
	}

	battler.charLen = j

	battler.ShowCharStatus()

	return FILTER, cmdLst[0], nil
}

func (battler *OfflineBattler) HandleCmd15(cmd int, dir int, context []byte,
	parser *DataParse, pass io.Writer, reply io.Writer) (int, []byte, error) {

	cmdLst := bytes.Split(context, []byte("|"))

	switch string(cmdLst[0]) {
	case "BA":
		return battler.HandleCmd15BA(cmd, dir, cmdLst, parser, pass, reply)
	case "BC":
		return battler.HandleCmd15BC(cmd, dir, cmdLst, parser, pass, reply)
	case "BP":
		return FILTER, cmdLst[0], nil
	case "BH": //战斗结果,直接返回,不需要战斗结果
		return FILTER, cmdLst[0], nil
	case "BE":
		if "f1" == string(cmdLst[2]) {
			battler.replyFinishBattle(parser, pass, reply)
		}
		return FILTER, cmdLst[0], nil
	case "FFF":
		return FILTER, cmdLst[0], nil
	case "bn":
		if "BE" == string(cmdLst[2]) && "f1" == string(cmdLst[4]) {
			battler.replyFinishBattle(parser, pass, reply)
		}
		return FILTER, cmdLst[0], nil

	default:
		fmt.Printf("not recognize %s cmd\n", string(cmdLst[0]))
	}

	return BYPASS, cmdLst[0], nil

}

func (battler *OfflineBattler) HandleCmd(cmd int, dir int, context [][]byte,
	parser *DataParse, pass io.Writer, reply io.Writer) (int, []byte, error) {

	cmdRealId := GetRealCmd(cmd, dir)

	if outFmtCmd[cmdRealId] > 0 {
		fmt.Printf("cmd(%d:%d) %s ", cmd, cmdRealId, constString[dir-1])
	}

	offlineOn := FILTER

	switch cmdRealId {
	case 211: //战斗的时候会接收到的第一个命令
		value, _ := parser.DeString(context[0])
		sum, _ := parser.DeInt(context[1])

		fmt.Printf("%s %d\n", value, sum)

		battler.ChangeStatus(cmd)

		return offlineOn, []byte{}, nil
	case 2:

		if battler.battlerWaitCmd2 {
			battler.battlerWaitCmd2 = false
			battler.replyFinishBattle(parser, pass, reply)
		}

		return BYPASS, []byte{}, nil

	case 46:
		//value, _ := parser.DeString(context[0])
		//sum, _ := parser.DeInt(context[1])

		//fmt.Printf("%s %d\n", value, sum)

		return BYPASS, []byte{}, nil

	case 14:
		value, _ := parser.DeString(context[0])
		sum, _ := parser.DeInt(context[1])

		fmt.Printf("%s %d\n", value, sum)

		return BYPASS, []byte{}, nil

	case 15:
		value, _ := parser.DeString(context[0])
		sum, _ := parser.DeInt(context[1])

		fmt.Printf("%s %d\n", value, sum)

		if offlineOn != BYPASS {
			battler.HandleCmd15(cmd, dir, value, parser, pass, reply)
		}

		return offlineOn, []byte{}, nil
	case 7: //战斗的时候会接收到的第二个命令
		value, _ := parser.DeInt(context[0])
		field, _ := parser.DeInt(context[1])

		fmt.Printf("%d %d\n", value, field)

		battler.ChangeStatus(cmd)

		return offlineOn, []byte{}, nil

	default:
		return BYPASS, []byte{}, nil
	}
}
