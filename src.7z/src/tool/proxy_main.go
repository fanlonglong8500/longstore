package main

import (
	"bufio"
	"fmt"
	"net"
	"socks5"

	"io"
	"log"
	"os"
	"sync"
)

const (
	LOGA = -111111
)

const (
	BYPASS  = 1
	REPLACE = 2
	FILTER  = 3
)

var logType map[int]int = map[int]int{
	15:   1,
	14:   1,
	7:    1,
	LOGA: 1,
}

type proxyStore struct {
	parser  *DataParse
	cmd     *CmdHandler
	keyGen  *KeyGen
	battler *OfflineBattler
}

type genProxyStore struct {
	name string
}

type lockWriter struct {
	locker sync.Mutex
	writer io.Writer
}

func (genProxyer *genProxyStore) New() socks5.Proxyer {
	return &proxyStore{
		parser:  &DataParse{},
		cmd:     &CmdHandler{},
		keyGen:  &KeyGen{},
		battler: &OfflineBattler{},
	}
}

func (writer *lockWriter) Write(p []byte) (n int, err error) {
	writer.locker.Lock()
	defer writer.locker.Unlock()

	return writer.writer.Write(p)
}

/*
type cPet struct {
	name    [256]byte //要抓宠物的名字,二进制
	nameLen int
	level   int64 //要抓宠物的等级,不超过这个等级
	hp      int64 // 0 代表不关心血量，其他的值代表必须超过这个值
}
*/
var battlerFmt OfflineBattler = OfflineBattler{
	battlerAction:   1,  // 1.逃跑 2.战斗
	capturePet:      1,  // 1.抓宠 0.不抓
	cureLevel:       80, //0-100 低于这个比例就治疗
	cureSkill:       1,  //治疗技能
	capturePetSkill: 2,  //猛毒
	petLst: []cPet{
		cPet{ //迪基格斯
			name:    [256]byte{0xb5, 0xcf, 0xbb, 0xf9, 0xb8, 0xf1, 0xcb, 0xb9},
			nameLen: 8,
			level:   15,
		},
		/*
			cPet{ //扬奇洛斯
				name:    [256]byte{0xd1, 0xef, 0xc6, 0xe6, 0xc2, 0xe5, 0xcb, 0xb9},
				nameLen: 8,
				level:   2,
			},
		*/
		cPet{ //水舌头
			name:    [256]byte{0xb1, 0xb4, 0xc2, 0xe5, 0xb6, 0xf7},
			nameLen: 6,
			level:   1,
			hp:      53,
		},
	}, //抓宠的列表
}

func (core *proxyStore) ProxyLine(reader *bufio.Reader, pass *lockWriter, reply *lockWriter, errCh chan error) {

	for {
		buf, err := reader.ReadBytes(0xa)
		if err != nil {
			errCh <- err
			return
		}

		cmd, err := core.parser.DecodeData(buf)
		if err != nil {
			errCh <- err
			return
		}

		cmdId, cmdDirect, cmdLst, err := core.parser.GetCommandID(cmd)
		if err != nil {
			errCh <- err
			return
		}

		//	core.cmd.HandleCmd(cmdId, context, parser)

		cmdRealId := GetRealCmd(cmdId, cmdDirect)

		if logType[cmdRealId] > 0 || logType[LOGA] > 0 {

			log.Printf("cmdId %d:%d dir %s ", cmdId, cmdRealId, constString[cmdDirect-1])

			for i := 0; i < len(cmdLst); i++ {
				if 6 == len(cmdLst[i]) {
					value, _ := core.parser.DeInt(cmdLst[i])
					log.Printf("%x ", value)
				} else {
					value, _ := core.parser.DeString(cmdLst[i])
					log.Printf("%s ", value)
				}
			}

			log.Println("")
		}

		action, mbuf, err := core.battler.HandleCmd(cmdId, cmdDirect, cmdLst, core.parser, pass, reply)
		if err != nil {
			errCh <- err
			return
		}

		switch action {
		case FILTER:
			continue
		case BYPASS:
			num, err := pass.Write(buf)
			if err != nil || num < len(buf) {
				errCh <- err
				return
			}
		case REPLACE:
			num, err := pass.Write(mbuf)
			if err != nil || num < len(mbuf) {
				errCh <- err
				return
			}
		default:
			log.Println("not recognize action ", action)
			continue
		}
	}
}

func (core *proxyStore) ProxyHandle(
	clientToProxy, proxyToServer net.Conn, errCh chan error) error {
	log.Println("new client come in")

	core.keyGen.LoadSeeds(
		"F:\\source\\storeage\\stone-age-master\\stone-age-master\\client\\526sa\\key.mem")

	*core.battler = battlerFmt

	log.Printf("keygen load 0 %x\n", core.keyGen.Seed0[0])

	readFromServer := bufio.NewReader(proxyToServer)
	readFromClient := bufio.NewReader(clientToProxy)

	keySeed, err := readFromServer.ReadBytes(0x0)
	if err != nil {
		errCh <- err
		return err
	}

	log.Println("recv key is ", string(keySeed[1:len(keySeed)-1]))

	input := StringToByte(string(keySeed[1 : len(keySeed)-1]))
	key, err := core.keyGen.GetKeys(input, 2)
	if err != nil {
		errCh <- err
		return err
	}

	num, err := clientToProxy.Write(keySeed)
	if err != nil || num < len(keySeed) {
		errCh <- err
		return err
	}

	core.parser.Key = string(key[0:8]) + string(key[0:8])

	for {
		userInfo, err := readFromClient.ReadBytes(0xa)
		if err != nil {
			errCh <- err
			return err
		}

		cmd, err := core.parser.DecodeData(userInfo)
		if err != nil {
			errCh <- err
			return err
		}

		fmt.Printf("cmd is %s\n", string(cmd))
		log.Printf("cmd is %s\n", string(cmd))

		cmdNum, _, cmdLst, err := core.parser.GetCommandID(cmd)
		if err != nil {
			errCh <- err
			return err
		}

		fmt.Printf("first CTOS cmd is %d\n", cmdNum)
		log.Printf("first CTOS cmd is %d\n", cmdNum)

		num, err = proxyToServer.Write(userInfo)
		if err != nil || num < len(userInfo) {
			errCh <- err
			return err
		}

		if cmdNum == 84 {
			userName, err := core.parser.DeString(cmdLst[0])
			if err != nil {
				errCh <- err
				return err
			}

			core.parser.Key = string(userName) + string(key[0:8])

			fmt.Printf("key is %s\n", core.parser.Key)
			log.Printf("key is %s\n", core.parser.Key)

			break
		}
	}

	waitCh := make(chan error, 2)

	var clientToProxyWriter *lockWriter = &lockWriter{writer: clientToProxy}
	var proxyToServerWriter *lockWriter = &lockWriter{writer: proxyToServer}

	go core.ProxyLine(readFromServer, clientToProxyWriter, proxyToServerWriter, waitCh)
	go core.ProxyLine(readFromClient, proxyToServerWriter, clientToProxyWriter, waitCh)

	for i := 0; i < 2; i++ {
		err = <-waitCh
	}

	return err
}

func initLogs() {

	fmt.Println("init logs")

	f, err := os.OpenFile("log.txt", os.O_WRONLY|os.O_CREATE|os.O_APPEND, 0755)
	if err != nil {
		fmt.Println("init logs failed")
		return
	}
	log.SetOutput(f)
}

func runProxyServer() {
	conf := &socks5.Config{}
	server, err := socks5.New(conf, &genProxyStore{})
	if err != nil {
		log.Println("socks5 new error")
		return
	}

	listenAddr := "127.0.0.1:8000"

	log.Println("listener ", listenAddr)

	// Create SOCKS5 proxy on localhost port 8000
	if err := server.ListenAndServe("tcp", listenAddr); err != nil {
		log.Println("socks5 new error")
		return
	}
}

func main() {

	initLogs()
	runProxyServer()
}
